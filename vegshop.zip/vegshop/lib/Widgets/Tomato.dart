import 'package:flutter/material.dart';

class Tomato extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
        child: Wrap(
      children: [
        Container(
          width: 430,
          height: 1320,
          clipBehavior: Clip.antiAlias,
          decoration: BoxDecoration(color: Color(0xFFFFDFA2)),
          child: Stack(
            children: [
              Positioned(
                left: 155,
                top: 172,
                child: Container(
                  width: 120,
                  height: 141,
                  clipBehavior: Clip.antiAlias,
                  decoration: BoxDecoration(color: Colors.white),
                  child: Stack(
                    children: [
                      Positioned(
                        left: -14,
                        top: 0,
                        child: Container(
                          width: 158,
                          height: 107,
                          decoration: BoxDecoration(
                            image: DecorationImage(
                              image: AssetImage('images/tomato.png'),
                              fit: BoxFit.fill,
                            ),
                          ),
                        ),
                      ),
                      Positioned(
                        left: 11,
                        top: 111,
                        child: Text(
                          'Tomato',
                          style: TextStyle(
                            color: Colors.black,
                            fontSize: 13,
                            fontFamily: 'Inika',
                            fontWeight: FontWeight.w400,
                            height: 0,
                          ),
                        ),
                      ),
                      Positioned(
                        left: 74,
                        top: 124,
                        child: SizedBox(
                          width: 57,
                          child: Text(
                            '\$4.99/lb',
                            style: TextStyle(
                              color: Colors.black,
                              fontSize: 11,
                              fontFamily: 'Inika',
                              fontWeight: FontWeight.w400,
                              height: 0,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                left: 34,
                top: 119,
                child: SizedBox(
                  width: 334,
                  height: 37,
                  child: Text(
                    'Veg Product - Tomato',
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 24,
                      fontFamily: 'Inika',
                      fontWeight: FontWeight.w400,
                      height: 0,
                    ),
                  ),
                ),
              ),
              Positioned(
                left: 28,
                top: 156,
                child: Container(
                  width: 339,
                  decoration: ShapeDecoration(
                    shape: RoundedRectangleBorder(
                      side: BorderSide(
                        width: 1,
                        strokeAlign: BorderSide.strokeAlignCenter,
                      ),
                    ),
                  ),
                ),
              ),
              Positioned(
                left: 0,
                top: 51,
                child: Container(
                  width: 430,
                  height: 52,
                  decoration: BoxDecoration(color: Color(0xFFFFA011)),
                ),
              ),
              Positioned(
                left: 368,
                top: 55,
                child: Container(
                  width: 58,
                  height: 57,
                  decoration: ShapeDecoration(
                    color: Colors.white,
                    shape: StarBorder.polygon(sides: 3),
                  ),
                ),
              ),
              Positioned(
                left: 385,
                top: 55,
                child: SizedBox(
                  width: 41,
                  height: 25,
                  child: Text(
                    'veg shop logo',
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 12,
                      fontFamily: 'Inika',
                      fontWeight: FontWeight.w400,
                      height: 0,
                    ),
                  ),
                ),
              ),
              Positioned(
                left: 76,
                top: 51,
                child: GestureDetector(
                  onTap: () {
                    // Navigate to the "AboutUs" page
                    Navigator.pushNamed(context, '/aboutUs');
                  },
                  child: Container(
                    width: 72,
                    height: 52,
                    child: Stack(
                      children: [
                        Positioned(
                          left: 0,
                          top: 0,
                          child: Container(
                            width: 72,
                            height: 52,
                            decoration: BoxDecoration(color: Color(0xFFFFA011)),
                          ),
                        ),
                        Positioned(
                          left: 4.58,
                          top: 16.93,
                          child: SizedBox(
                            width: 72,
                            height: 52,
                            child: Text(
                              'About us ',
                              style: TextStyle(
                                color: Colors.black,
                                fontSize: 15,
                                fontFamily: 'Itim',
                                fontWeight: FontWeight.w400,
                                height: 0,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              Positioned(
                left: 2,
                top: 50,
                child: Container(
                  width: 72,
                  height: 52,
                  child: GestureDetector(
                      onTap: () {
                        // Navigate to the "AboutUs" page
                        Navigator.pushNamed(context, '/');
                      },
                      child: Stack(
                        children: [
                          Positioned(
                            left: 0,
                            top: 0,
                            child: Container(
                              width: 72,
                              height: 52,
                              decoration:
                                  BoxDecoration(color: Color(0xFFFFA011)),
                            ),
                          ),
                          Positioned(
                            left: 0,
                            top: 16.93,
                            child: SizedBox(
                              width: 72,
                              height: 52,
                              child: Text(
                                'Veg Shop',
                                style: TextStyle(
                                  color: Colors.black,
                                  fontSize: 15,
                                  fontFamily: 'Itim',
                                  fontWeight: FontWeight.w400,
                                  height: 0,
                                ),
                              ),
                            ),
                          ),
                        ],
                      )),
                ),
              ),
              Positioned(
                left: 148,
                top: 51,
                child: GestureDetector(
                  onTap: () {
                    // Navigate to the "AboutUs" page
                    Navigator.pushNamed(context, '/shop');
                  },
                  child: Container(
                      width: 72,
                      height: 52,
                      child: Stack(
                        children: [
                          Positioned(
                            left: 0,
                            top: 0,
                            child: Container(
                              width: 72,
                              height: 52,
                              decoration:
                                  BoxDecoration(color: Color(0xADEF4949)),
                            ),
                          ),
                          Positioned(
                            left: 0,
                            top: 16.93,
                            child: SizedBox(
                              width: 72,
                              height: 52,
                              child: Text(
                                'Shop',
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  color: Colors.black,
                                  fontSize: 15,
                                  fontFamily: 'Itim',
                                  fontWeight: FontWeight.w400,
                                  height: 0,
                                ),
                              ),
                            ),
                          ),
                        ],
                      )),
                ),
              ),
              Positioned(
                left: 220,
                top: 51,
                child: Container(
                  width: 72,
                  height: 52,
                  child: Stack(
                    children: [
                      Positioned(
                        left: 0,
                        top: 0,
                        child: Container(
                          width: 72,
                          height: 52,
                          decoration: BoxDecoration(color: Color(0xFFFFA011)),
                        ),
                      ),
                      Positioned(
                        left: 0,
                        top: 16.93,
                        child: SizedBox(
                          width: 72,
                          height: 52,
                          child: Text(
                            'Cart',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              color: Colors.black,
                              fontSize: 15,
                              fontFamily: 'Itim',
                              fontWeight: FontWeight.w400,
                              height: 0,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                left: 292,
                top: 51,
                child: GestureDetector(
                  onTap: () {
                    // Navigate to the "AboutUs" page
                    Navigator.pushNamed(context, '/contactUs');
                  },
                  child: Container(
                      width: 72,
                      height: 52,
                      child: Stack(
                        children: [
                          Positioned(
                            left: 0,
                            top: 0,
                            child: Container(
                              width: 72,
                              height: 52,
                              decoration:
                                  BoxDecoration(color: Color(0xFFFFA011)),
                            ),
                          ),
                          Positioned(
                            left: 5.24,
                            top: 11.49,
                            child: SizedBox(
                              width: 72,
                              height: 52,
                              child: Text(
                                'Contract\nus',
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  color: Colors.black,
                                  fontSize: 15,
                                  fontFamily: 'Itim',
                                  fontWeight: FontWeight.w400,
                                  height: 0,
                                ),
                              ),
                            ),
                          ),
                        ],
                      )),
                ),
              ),
              Positioned(
                left: -3,
                top: 1040,
                child: Container(
                  width: 430,
                  height: 280,
                  decoration: BoxDecoration(
                    image: DecorationImage(
                      image: AssetImage('images/bottom.png'),
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ),
              Positioned(
                left: 27,
                top: 312,
                child: Container(
                  width: 390,
                  height: 845,
                  child: Stack(
                    children: [
                      Positioned(
                        left: 0,
                        top: 45,
                        child: Container(
                          width: 193,
                          height: 400,
                          decoration: BoxDecoration(
                            image: DecorationImage(
                              image: AssetImage('images/TopL.png'),
                              fit: BoxFit.fill,
                            ),
                          ),
                        ),
                      ),
                      Positioned(
                        left: 193,
                        top: 45,
                        child: Container(
                          width: 193,
                          height: 400,
                          decoration: BoxDecoration(
                            image: DecorationImage(
                              image: AssetImage('images/TopR.png'),
                              fit: BoxFit.fill,
                            ),
                          ),
                        ),
                      ),
                      Positioned(
                        left: 0,
                        top: 445,
                        child: Container(
                          width: 193,
                          height: 400,
                          decoration: BoxDecoration(
                            image: DecorationImage(
                              image: AssetImage('images/LowerL.png'),
                              fit: BoxFit.fill,
                            ),
                          ),
                        ),
                      ),
                      Positioned(
                        left: 3,
                        top: 0,
                        child: Container(
                          width: 380,
                          height: 31,
                          decoration: BoxDecoration(
                            image: DecorationImage(
                              image: AssetImage('images/Mid.png'),
                              fit: BoxFit.fill,
                            ),
                          ),
                        ),
                      ),
                      Positioned(
                        left: 193,
                        top: 445,
                        child: Container(
                          width: 197,
                          height: 306,
                          decoration: BoxDecoration(
                            image: DecorationImage(
                              image: AssetImage('images/LowerR.png'),
                              fit: BoxFit.fill,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                left: -13,
                top: 3,
                child: Container(
                  width: 443,
                  height: 48,
                  decoration: BoxDecoration(
                    image: DecorationImage(
                      image: AssetImage('images/Top.png'),
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ),
              Positioned(
                left: 298,
                top: 3,
                child: GestureDetector(
                    onTap: () {
                      // Navigate to the "AboutUs" page
                      Navigator.pushNamed(context, '/');
                    },
                    child: Text.rich(
                      TextSpan(
                        children: [
                          TextSpan(
                            text: 'Veg Shop\n',
                            style: TextStyle(
                              color: Colors.black,
                              fontSize: 24,
                              fontFamily: 'Itim',
                              fontWeight: FontWeight.w400,
                              height: 0,
                            ),
                          ),
                          TextSpan(
                            text: 'by Team Veggies',
                            style: TextStyle(
                              color: Colors.black,
                              fontSize: 10,
                              fontFamily: 'Itim',
                              fontWeight: FontWeight.w400,
                              height: 0,
                            ),
                          ),
                        ],
                      ),
                      textAlign: TextAlign.right,
                    )),
              ),
            ],
          ),
        ),
      ],
    ));
  }
}
